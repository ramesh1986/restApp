//Form JS File
function addWidgetsfrmHome() {
    var btnHam = new kony.ui.Button({
        "id": "btnHam",
        "top": "1dp",
        "left": "2dp",
        "width": "56dp",
        "height": "52dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Hamburger button",
        "skin": "btnNormal",
        "focusSkin": "btnFocus"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var label2129799142615 = new kony.ui.Label({
        "id": "label2129799142615",
        "top": "1dp",
        "left": "58dp",
        "width": "389dp",
        "height": "50dp",
        "zIndex": 1,
        "isVisible": true,
        "text": "Menu Contents",
        "skin": "lblNormal"
    }, {
        "padding": [0, 0, 0, 0],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 0
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var flexContainer2129799142613 = new kony.ui.FlexContainer({
        "id": "flexContainer2129799142613",
        "top": "0dp",
        "left": "0dp",
        "width": "100%",
        "height": "52dp",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,0]",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    flexContainer2129799142613.setDefaultUnit(kony.flex.DP)
    flexContainer2129799142613.add(
    btnHam, label2129799142615);
    var flexMenuDetails = new kony.ui.FlexContainer({
        "id": "flexMenuDetails",
        "top": "59dp",
        "width": "99.5%",
        "height": "274dp",
        "zIndex": 1,
        "isVisible": true,
        "clipBounds": true,
        "Location": "[0,59]",
        "layoutType": kony.flex.FREE_FORM
    }, {
        "padding": [0, 0, 0, 0]
    }, {});;
    flexMenuDetails.setDefaultUnit(kony.flex.DP)
    flexMenuDetails.add();
    frmHome.add(
    flexContainer2129799142613, flexMenuDetails);
};

function frmHomeGlobals() {
    var MenuId = [];
    frmHome = new kony.ui.Form2({
        "id": "frmHome",
        "enableScrolling": true,
        "bounces": true,
        "allowHorizontalBounce": true,
        "allowVerticalBounce": true,
        "pagingEnabled": false,
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "frm",
        "bouncesZoom": true,
        "zoomScale": 1.0,
        "minZoomScale": 1.0,
        "maxZoomScale": 1.0,
        "layoutType": kony.flex.FREE_FORM,
        "addWidgets": addWidgetsfrmHome
    }, {
        "padding": [0, 0, 0, 0],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": false
    }, {
        "retainScrollPosition": false,
        "needsIndicatorDuringPostShow": true,
        "formTransparencyDuringPostShow": "100",
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "configureExtendTop": false,
        "configureExtendBottom": false,
        "configureStatusBarStyle": false,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "outTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        }
    });
    frmHome.setDefaultUnit(kony.flex.DP);
};